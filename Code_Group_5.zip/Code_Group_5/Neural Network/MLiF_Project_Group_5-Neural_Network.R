####################################################################################################################################################################################################

#Machine Learning in Finance: Group 5 Project - Predicting bond ratings for S&P-rated companies using financial ratios
#
# Import data: MLiF_Dataset.csv
# Task: train Neural Network Algo to predict rating of S%P Rated companies - We did the linear transformation so we are predicting a numeric value, the score
# Joshua Libon, Noa Diego Frei, Lev Akhmerov, Julius Everwand, Leo Koch

####################################################################################################################################################################################################


#Import Libraries needed
library(ggplot2)
library(readr)
library(dplyr)
library(lattice)
library(caret)
library(reshape2)
library(readxl)
library(here)



#Begin of Code

#Import Libraries needed
library(ggplot2)
library(readr)
library(dplyr)
library(lattice)
library(caret)
library(reshape2)
library(readxl)
library(here)
library(corrplot)
library(future)
library(future.apply)

#Begin of Code

#################################################CLEANING OF DATASET (only done once (in RF code), the used also for LR and NN, copy paste in other scripts)########################################
#import the dataset to use
current_context <- rstudioapi::getActiveDocumentContext()
file_path <- current_context$path
parent_directory <- dirname(file_path)
data_folder_path <- file.path(dirname(parent_directory), "Dataset")
csv_path <- file.path(data_folder_path, "MLiF_Dataset.csv")
financial_data <- read_csv(csv_path)
#if that does not work, write: financial_data <- read_csv("...your path/MLiF_Dataset.csv")

#Have a first look at the data
head(financial_data)
column_names <- colnames(financial_data)
column_names

#save original dataset to be used again later if needed
financial_data_2<-financial_data


#Clean the data

#Check for NAs
total_nas <- sum(is.na(financial_data))
if (total_nas!=0){
  print("Pleasem check your data and clean it")
}else{
  print(paste("The total number of NAs is:", total_nas)) # should be 0
}

#clean the dataset columns name-had some problems with the random forest
financial_data <- financial_data %>%
  rename_with(~ gsub(" ", "_", .x)) %>%  # Replace spaces with underscores
  rename_with(~ gsub("/", "_", .x)) %>%  # Replace slashes with underscores
  rename_with(~ gsub("-", "_", .x))       # Replace - with underscores

nrow(financial_data)
ncol(financial_data)

#remove some columns-cleaninig
financial_data <- financial_data[ , !(names(financial_data) %in% c("Global_Company_Key", "Date", "Rating", "Ticker_Symbol", "Quick_Ratio_(Acid_Test)", "Historical_CRSP_PERMNO_Link_to_COMPUSTAT_Record", "Total_Debt_Total_Assets...42"))]
#financial_data <- financial_data[ , !(names(financial_data) %in% c("Global_Company_Key", "Date", "Score", "Ticker_Symbol", "Quick_Ratio_(Acid_Test)", "Historical_CRSP_PERMNO_Link_to_COMPUSTAT_Record", "Total_Debt_Total_Assets...42"))]

column_28_name <- names(financial_data)[28]
print(column_28_name)
colnames(financial_data)[colnames(financial_data) == column_28_name] <- "Total_Debt_Total_Assets"

#Check if it worked
column_names <- colnames(financial_data)
column_names

# Check if each column is a double
double_check <- sapply(financial_data, is.double)
double_check


#For test and train, later useful
target_column <- "Score"
#select only features (all columns except what we want to predict)
features <- financial_data[, setdiff(names(financial_data), target_column)]
target <- financial_data[[target_column]]#what we want to predict
#index of target column
target_column_index <- which(names(financial_data) == target_column)
print(target_column_index)

#more cleaning 
class(financial_data[, target_column_index])
outcome <- financial_data[[target_column_index]]
outcome <- as.numeric(outcome)
class(outcome)
outcome <- financial_data[[target_column_index]]


#convert to vectors to be sure - had some problems with random forest, should already be a vector but just to be sure
financial_data <- financial_data %>%
  mutate_all(as.vector)
#Double check
sapply(financial_data, class)


#Save final cleaned dataset
cleaned_financial_dataset<-financial_data
column_names <- colnames(cleaned_financial_dataset)
column_names
nrow(cleaned_financial_dataset)
ncol(cleaned_financial_dataset)
cleaned_financial_dataset<-as.data.frame(cleaned_financial_dataset)



################################################# END OF CLEANING OF DATASET #######################################################################################################################


################################################ START OF RF CODE ##################################################################################################################################

#Neural Net
#Load packages
library(MASS) 
library(caTools)
library(neuralnet)
library(knitr)

#Preprocessing
#1. Standardize data
#Normalize : min-max scale, z-normalization etc

#grab min and max value per column using the apply function.
maxs <- apply(cleaned_financial_dataset, MARGIN=2, max) #margin 2 means we want to apply this function to column. help(apply) for more info.
maxs #(max values of each of the columns.)


mins <- apply(cleaned_financial_dataset, MARGIN=2, min)
mins


#help(scale) scale is going to return numeric matrix -> will need to change back to df
scaled.data <- scale(cleaned_financial_dataset, center = mins, scale = maxs - mins) # This means, each data value will be subtracted by the mins, then divided by max-mins. so get data, subtract mins and divide by max-mins.
scaled <- as.data.frame(scaled.data) # turn the matrix into frame.

head(scaled)
summary(scaled)

head(cleaned_financial_dataset)

#2. now split train / test 

library(caTools) 

set.seed(7)

#70% Train, 30% Test
split <- sample.split(scaled$Score, SplitRatio = 0.7)
train <- subset(scaled, split == T)
test <- subset(scaled, split == F)

#This is important, you have to normalize your data like this at all times.

#3. train the model

#The format for neuralnet: y ~ col1 + col2 .
#since that's a bit redundant...we will do this way
n <- names(train)
n


f <- as.formula(paste("Score ~", paste(n[!n %in% "Score"], collapse = " + ")))
f

#hidden: vector of integers, specifying number of hidden neurons in each layers. (first hidden layer of 5 neurons, second hidden layer of 3 neurons)
#linear.output: Whether this is continuous value, so in our case it's TRUE
nn <- neuralnet(f, data = train, hidden = c(5,3), linear.output = TRUE) 

plot(nn, cex = 0.3) # decreased font size

#This is like black box, it's really hard to interpret what each of these weighted vectors really means in reference to the column values of the data.
#the black lines, shows the connection between each layer and weights of each connection.
#blue lines shows the bias term added in each step.
#bias can be thought almost like intercept of linear model.
#the net here is like black box. we can't say much about the fitting the weights or even the model.
#But we can say that this training algorithm converged, and therefore, the model is ready to be used on test data.


#create prediction with model
predicted.nn.values <- compute(nn, test[1:50]) # All columns except our Y (Score)
str(predicted.nn.values) # scaled results

#this is list of neurons and net.result. and what we want is net result.
#but we scaled the data earlier for the training model.
#So we need to undo the operation in order to obtain the true predictions!

true.predictions <- predicted.nn.values$net.result * 
  (max(cleaned_financial_dataset$Score) - min(cleaned_financial_dataset$Score)) + min(cleaned_financial_dataset$Score)

#we were subtracting from the center value and then dividing by that scale value to perform our normalization operation.
#So for true.predictions, we are inverting this.

#convert the test data
test.r <- (test$Score) * (max(cleaned_financial_dataset$Score) - min(cleaned_financial_dataset$Score)) + min(cleaned_financial_dataset$Score)
MSE.nn <- sum((test.r - true.predictions)^2)/nrow(test)
print(paste("Average MSE with 70% Train and 30% Test:", MSE.nn))


#we can visualize error in ggplot2 by actually just graphically showing the true predictions plotted by the test values.
error.df <- data.frame(test.r, true.predictions)
head(error.df)

#visualization of the error 
#red line: Linear fit of neural network predicted data points
#blue line: Angle bisector, perfect predictor
library(ggplot2)
ggplot(error.df, aes(x = test.r, y = true.predictions)) + 
  geom_point(shape = 1, color = "black", size = 2) + 
  stat_smooth(method = "lm", color = "red", se = FALSE) +
  labs(title = "True vs Predicted Values (70% Train and 30% Test)", x = "True Score", y = "Predicted Score") +
  geom_abline(intercept = 0, slope = 1, color = "blue", linetype = "dashed") +  # 45-degree reference line
  theme_minimal()

#prepare for 10-Fold Cross-Validation
set.seed(120) #for reproducibility
folds <- sample(rep(1:10, length.out = nrow(scaled)))

#lists to store predicted and true values for each fold
y.predicted.plot <- c()
y.true.plot <- c()
cv_mse <- c()

#10-Fold Cross-Validation loop
for (k in 1:10) {  #loop through all 10 folds
  #training and test data for the current fold
  train <- scaled[folds != k, ]
  test <- scaled[folds == k, ]
  
  #formula for the neural network
  n <- names(train)
  f <- as.formula(paste("Score ~", paste(n[!n %in% "Score"], collapse = " + ")))
  
  #train the model
  nn <- neuralnet(f, data = train, hidden = c(5, 3), linear.output = TRUE)
  
  #make predictions for the current test dataset
  predicted.nn.values <- compute(nn, test[ , -which(names(test) == "Score")]) 
  
  #rescale the predictions back to the original value range
  true.predictions <- predicted.nn.values$net.result * (max(cleaned_financial_dataset$Score) - min(cleaned_financial_dataset$Score)) + min(cleaned_financial_dataset$Score)
  
  #store predicted and true values for the plot
  y.predicted.plot <- c(y.predicted.plot, true.predictions)
  
  #rescale the test data back to the original value range
  test.r <- (test$Score) * (max(cleaned_financial_dataset$Score) - min(cleaned_financial_dataset$Score)) + min(cleaned_financial_dataset$Score)
  y.true.plot <- c(y.true.plot, test.r)
  
  #calculate Mean Squared Error (MSE) for the current fold
  fold_mse <- sum((test.r - true.predictions)^2) / nrow(test)
  cv_mse <- c(cv_mse, fold_mse) #Store MSE for this fold
}

#calculate the average MSE across all folds
mean_cv_mse <- mean(cv_mse)
print(paste("Average MSE after 10-Fold CV:", mean_cv_mse))

#visualization of the error (Test vs. Predictions across all folds)
#red line: Linear fit of neural network predicted data points
#blue line: Angle bisector, perfect predictor
error.df <- data.frame(True_Score = y.true.plot, Predicted_Score = y.predicted.plot)
ggplot(error.df, aes(x = True_Score, y = Predicted_Score)) + 
  geom_point(shape = 1, color = "black", size = 2) + 
  stat_smooth(method = "lm", color = "red", se = FALSE) + 
  labs(title = "True vs Predicted Values (10-Fold CV)", x = "True Score", y = "Predicted Score") +
  geom_abline(intercept = 0, slope = 1, color = "blue", linetype = "dashed") +  # 45-degree reference line
  theme_minimal()
