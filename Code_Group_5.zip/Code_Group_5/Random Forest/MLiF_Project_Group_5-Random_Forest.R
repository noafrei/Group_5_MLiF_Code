####################################################################################################################################################################################################

# Machine Learning in Finance: Group 5 Project - Predicting bond ratings for S&P-rated companies using financial ratios
#
# Import data: MLiF_Dataset.csv
# Task: clean data and train Random Forest Algo to predict rating of S%P Rated companies - We did the linear transformation so we are predicting a numeric value (the score), not categorical
# 
# Noa Diego Frei, Lev Akhmerov, Joshua Libon, Julius Everwand, Leo Koch

####################################################################################################################################################################################################

#Import Libraries needed
library(ggplot2)
library(readr)
library(dplyr)
library(randomForest)
library(lattice)
library(caret)
library(randomForestSRC)
library(ggRandomForests)
library(reshape2)
library(readxl)
library(here)
library(corrplot)
library(future)
library(future.apply)

#Begin of Code

################################################# Cleaning of Dataset (only done once, the used also for LR and NN, copy paste in other scripts) ###################################################
#import the dataset to use
current_context <- rstudioapi::getActiveDocumentContext()
file_path <- current_context$path
parent_directory <- dirname(file_path)
data_folder_path <- file.path(dirname(parent_directory), "Dataset")
csv_path <- file.path(data_folder_path, "MLiF_Dataset.csv")
financial_data <- read_csv(csv_path)
#if that does not work, write: financial_data <- read_csv("...your path/MLiF_Dataset.csv")

#Have a first look at the data
head(financial_data)
column_names <- colnames(financial_data)
column_names

#save original dataset to be used again later if needed
financial_data_2<-financial_data


#Clean the data

#Check for NAs
total_nas <- sum(is.na(financial_data))
if (total_nas!=0){
  print("Pleasem check your data and clean it")
}else{
  print(paste("The total number of NAs is:", total_nas)) # should be 0
}

#clean the dataset columns name-had some problems with the random forest
financial_data <- financial_data %>%
  rename_with(~ gsub(" ", "_", .x)) %>%  # Replace spaces with underscores
  rename_with(~ gsub("/", "_", .x)) %>%  # Replace slashes with underscores
  rename_with(~ gsub("-", "_", .x))       # Replace - with underscores

nrow(financial_data)
ncol(financial_data)

#remove some columns-cleaninig
financial_data <- financial_data[ , !(names(financial_data) %in% c("Global_Company_Key", "Date", "Rating", "Ticker_Symbol", "Quick_Ratio_(Acid_Test)", "Historical_CRSP_PERMNO_Link_to_COMPUSTAT_Record", "Total_Debt_Total_Assets...42"))]
#financial_data <- financial_data[ , !(names(financial_data) %in% c("Global_Company_Key", "Date", "Score", "Ticker_Symbol", "Quick_Ratio_(Acid_Test)", "Historical_CRSP_PERMNO_Link_to_COMPUSTAT_Record", "Total_Debt_Total_Assets...42"))]

column_28_name <- names(financial_data)[28]
print(column_28_name)
colnames(financial_data)[colnames(financial_data) == column_28_name] <- "Total_Debt_Total_Assets"

#Check if it worked
column_names <- colnames(financial_data)
column_names

#Check if each column is a double
double_check <- sapply(financial_data, is.double)
double_check


#For test and train, later useful
target_column <- "Score"
#select only features (all columns except what we want to predict)
features <- financial_data[, setdiff(names(financial_data), target_column)]
target <- financial_data[[target_column]]#what we want to predict
#index of target column
target_column_index <- which(names(financial_data) == target_column)
print(target_column_index)

#more cleaning 
class(financial_data[, target_column_index])
outcome <- financial_data[[target_column_index]]
outcome <- as.numeric(outcome)
class(outcome)
outcome <- financial_data[[target_column_index]]


#convert to vectors to be sure - had some problems with random forest, should already be a vector but just to be sure
financial_data <- financial_data %>%
  mutate_all(as.vector)
#Double check
sapply(financial_data, class)


#Save final cleaned dataset
cleaned_financial_dataset<-financial_data
column_names <- colnames(cleaned_financial_dataset)
column_names
nrow(cleaned_financial_dataset)
ncol(cleaned_financial_dataset)
cleaned_financial_dataset<-as.data.frame(cleaned_financial_dataset)


################################################# end of cleaning ##################################################################################################################################


################################################# Explore the dataset ##############################################################################################################################

#general summary
summary(cleaned_financial_dataset)


#compute some statistics-could also add other things like quantile etc, maybe to do later
statistics <- function(x) {
  if (is.numeric(x)) {
    c(count = sum(!is.na(x)),   # Count of non-missing values
      mean = mean(x, na.rm = TRUE),
      median = median(x, na.rm = TRUE),
      sd = sd(x, na.rm = TRUE),
      min = min(x, na.rm = TRUE),
      max = max(x, na.rm = TRUE))
  } else {
    return(NULL)
  }
}

numeric_stats <- sapply(cleaned_financial_dataset, statistics)
#Transpose to make it more readable
numeric_stats <- t(numeric_stats)
print(numeric_stats)

#Convert to a data frame
dataset_statistics <- as.data.frame(numeric_stats)
#change name of rows
dataset_statistics <- cbind(Variable = rownames(dataset_statistics), dataset_statistics)
rownames(dataset_statistics) <- NULL

print(dataset_statistics)
#save the dataset to show during presentation
write.csv(dataset_statistics, "dataset_statistics.csv", row.names = FALSE)

#correlation matrix
cor_matrix <- cor(cleaned_financial_dataset, use = "complete.obs")
melted_cor_matrix <- melt(cor_matrix)#needed for better visualization
ggplot(data = melted_cor_matrix, aes(x=Var1, y=Var2, fill=value)) + 
  geom_tile(color = "white") +
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                       midpoint = 0, limit = c(-1,1), space = "Lab", 
                       name="Correlation") +
  theme_minimal() + # Minimal theme
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1, size = 5), # Adjust size here
        axis.text.y = element_text(size = 5))
  coord_fixed()


#Frequency of our Ratings

#Count occurrences of each rating
rating_counts <- table(financial_data_2$Rating)
rating_counts_df <- as.data.frame(rating_counts)

#Rename columns for clarity, just to be sure
colnames(rating_counts_df) <- c("Rating", "Freq")

#I want the x-axis to be in a certain order
rating_order <- c("AAA", "AA+", "AA", "AA-", "A+", "A", "A-","BBB+", "BBB", "BBB-", "BB+", "BB", "BB-", "B+", "B", "B-", "CCC+", "CCC", "CCC-", "CC", "C", "D")

#Convert the Rating column to a factor with the specified order
rating_counts_df$Rating <- factor(rating_counts_df$Rating, levels = rating_order)

# Create a bar plot with the frequencies
ggplot(rating_counts_df, aes(x = Rating, y = Freq, fill = Rating)) +
  geom_bar(stat = "identity", width = 0.6) + 
  labs(title = "Frequency of the Various Ratings", x = "Rating", y = "Frequency") +
  theme_minimal() +
  scale_x_discrete(drop = FALSE)  # Ensures all ratings are shown
  theme(axis.text.x = element_text(size = 8)) 
  
#Calculate percentages and add as a new column
rating_counts_df <- rating_counts_df %>%
  mutate(Percentage = Freq / sum(Freq) * 100) %>%
  mutate(Label = paste0(Rating, ": ", round(Percentage, 1), "%"))  # Custom labels for legend

#Create the pie chart with percentages in the legend
ggplot(rating_counts_df, aes(x = "", y = Freq, fill = Label)) +  # Use custom labels
  geom_bar(stat = "identity", width = 1) + 
  coord_polar("y", start = 0) +  # Convert to pie chart
  labs(title = "Frequency of the Various Ratings", fill = "Rating and Percentage") +
  theme_void() +  # Use a minimal theme
  theme(legend.position = "right")  # Adjust legend position if needed



################################################# End of exploration ##############################################################################################################################


################################################ Start of RF Code ##################################################################################################################################

#Build the first random forest with default hyperparameters

set.seed(600)
default_random_forest <- randomForest( Score~ ., data = cleaned_financial_dataset, importance=TRUE, keep.forest = TRUE, keep.inbag = TRUE, ntree=500)

#Metrics
mse_values <- default_random_forest$mse
print(mse_values)
mean_mse <- mean(mse_values)
print(mean_mse)


#Try to increase number of trees
set.seed(600)
rf_test_more_trees <- randomForest( Score ~ ., data= cleaned_financial_dataset, importance=TRUE, keep.forest = TRUE, keep.inbag = TRUE, ntree=5000)
print(rf_test_more_trees)

rf_test_more_trees_2 <- randomForest( Score ~ ., data= cleaned_financial_dataset, importance=TRUE, keep.forest = TRUE, keep.inbag = FALSE, ntree=500)
print(rf_test_more_trees_2)



####################################################################################################################################################################################################


################################################ Expand algorithm - 10 fold CV - Hyperparameter Tuning #############################################################################################

set.seed(600)
#70-30 split
index <- createDataPartition(cleaned_financial_dataset$Score, p = 0.7, list = FALSE)
train_data <- cleaned_financial_dataset[index, ]
test_data <- cleaned_financial_dataset[-index, ]
features_train <- train_data[, -which(names(train_data) == "Score")]
target_train <- train_data$Score
features_test <- test_data[, -which(names(test_data) == "Score")]
target_test <- test_data$Score

#standard p/3->50/3
tunegrid <- expand.grid(.mtry=c(1:16))
control_cv_10_fold <- trainControl(method="cv", number=10, search="grid")
metric<- "Rsquared" 

rf_with_cv <- train(features_train, target_train, method="rf", metric=metric, tuneGrid=tunegrid, trControl=control_cv_10_fold, ntree = 500)
plot(rf_with_cv, col="black") #plot mtry vs rsquared

results_cv_10_fold <- list()
ntree_values = c(100, 200, 300, 400, 500, 700, 1000, 1500, 2000, 2200, 2400, 2600, 3000, 3500, 4000)

for (ntree in ntree_values){#this for loop takes a lot of time, maybe in the future try to do parrallel programming to use more cores and run it faster
  rf_with_cv_test <- train(features_train, target_train, method="rf", metric=metric, tuneGrid=tunegrid, trControl=control_cv_10_fold, ntree = ntree)
  results_cv_10_fold[[paste("ntree", ntree, sep = "_")]] <- rf_with_cv_test
}

length(results_cv_10_fold)  
ntrees_r_squared_cv_10_fold <- sapply(results_cv_10_fold, function(model) max(model$results$Rsquared))

plot(ntree_values, ntrees_r_squared_cv_10_fold, type = "b", col = "black", pch = 16, lty = 1,
     main = "Parameter Tuning",
     xlab = "# of Trees",
     ylab = "R-squared (Cross-Validation - 10 fold)")
grid()


#train final random forest with tuned parameters - #of trees = 700, mtry = 16
rf_final <- randomForest(features_train, target_train, ntree = 700, mtry = 16)

#Make predictions on the test set
test_predictions <- predict(rf_final, newdata = features_test)

traning_predictions<-predict(rf_final, newdata = features_train)

#Compute MSE on train set
mse_training <- mean((traning_predictions - target_train)^2)
print(paste("The MSE on the training train is:", mse_training)) 

#Compute MSE on test set
mse_test <- mean((test_predictions - target_test)^2)
print(paste("The MSE on the test is:", mse_test)) #MSE = 3.45770203230959

r_squared_test<-1 - (sum((target_test-test_predictions)^2)/sum((target_test-mean(target_test))^2))
r_squared_test #R_2 = 0.608313

#Build new dataset with predictions vs actual score
results_with_cv <- data.frame(
  Actual_Score  = target_test,        
  Predicted_Score = test_predictions,
  Delta = test_predictions-target_test
)
results_with_cv
#save the dataset to show during presentation
write.csv(results_with_cv, "results_with_cv.csv", row.names = FALSE)

################################################ Expand algorithm - LOOCV ##########################################################################################################################
set.seed(600)
control_loocv <- trainControl(method = "LOOCV")  # Leave-One-Out CV
#Train the random forest model using LOOCV
rf_model_loocv <- train(features_train, target_train, method = "rf",trControl = control_loocv, tuneGrid = tunegrid,ntree = 15)
plot(rf_model_loocv)
print(rf_model_loocv)

predictions_1<-predict(rf_model_loocv, newdata = features_test)
#Compute MSE on test set
mse_test_locv <- mean((predictions_1 - target_test)^2)
mse_test_locv

#tuninig again with LOOCV

#tried something in parallel because it took to long - but it didn't work, it took to long, maybe something is wrong in the code

cores <- parallel::detectCores() - 1  # number of cores to use
plan(multisession, workers = cores)   # tell the computer to use more cores

results_loocv<- list()
fresults_loocv <- future_lapply(ntree_values, function(ntree) {
  rf_with_loocv_test <- train(features_train, target_train,method = "rf",metric = metric, tuneGrid = tunegrid, trControl = control_loocv, ntree = ntree)#alternatively run with fewer trees so that it runs faster
  return(rf_with_loocv_test)  # Return the model for each ntree
})

names(results_loocv) <- paste("ntree", ntree_values, sep = "_")

ntrees_r_squared_loocv <- sapply(results_loocv, function(model) max(model$results$Rsquared))

plot(ntree_values, ntrees_r_squared_loocv, type = "b", col = "black", pch = 16, lty = 1,
     main = "Parameter Tuning",
     xlab = "# of Trees",
     ylab = "R-squared (Cross-Validation - LOOCV)")
grid()

plan(sequential)


################################################ End of RF Code ####################################################################################################################################

######################################## Variable importance (min depth and var importance) ########################################################################################################

#Calculate RF VARIABLES IMPORTANCE
#PERMUTATION IMPORTANCE
set.seed(600)
IMP<-importance(rf_final, type=1, scale=TRUE)
IMP
varImpPlot(rf_test_more_trees, 
           sort = TRUE, 
           type = 1, 
           main = 'Variable Importance Plot, %IncMSE', 
           scale = TRUE, 
           las = 2,            
           cex.axis = 0.8,    
           mgp = c(3, 1, 0))   


#MIN DEPTH IMPORTANCE 
set.seed(600)
varselect<-var.select(Score~., data=cleaned_financial_dataset, method='md', ntree=500, nodesize=5, mtry=4, block.size=1, conservative = "medium", refit = TRUE)
mdimp<- gg_minimal_depth(varselect)
plot(mdimp)

####################################################################################################################################################################################################
#In this section we try to adress to imbalance problem in our dataset, the fact that we have a lot of mid-rated companies, and very few that are either rated very good or very bad
#The idea is to use majority class under-sampling - found this approach in some literature and the book that was listed on canvas (The essential of Machine Learning in Finance and Accounting), and some youtube videos

#We get some different values depending on how we tune the various parameters, threshold and so on   

set.seed(600)

#70-30 split
train_index <- createDataPartition(cleaned_financial_dataset$Score, p = 0.7, list = FALSE)
train_data <- cleaned_financial_dataset[train_index, ]
test_data <- cleaned_financial_dataset[-train_index, ]

#Check class distribution in train and test sets
table(train_data$Score)
table(test_data$Score)

#Separate the minority and majority classes - threshold set by us
class_counts_train <- table(train_data$Score)
minority_classes <- names(class_counts_train[class_counts_train < 25])  # chose the treshold by looking at the data
majority_classes <- names(class_counts_train[class_counts_train >= 25])  #chose the treshold by looking at the data

#Keep all instances of the minority classes
minority_data <- train_data %>%
  filter(Score %in% minority_classes)

#Function to perform under-sampling of the majority classes- create smaller class with only 10 sample (randomly selected) from the majority class
create_under_sampled_dataset <- function() {
  sampled_majority <- train_data %>%
    filter(Score %in% majority_classes) %>%
    group_by(Score) %>%
    sample_n(size = 10) %>%  # Adjust sample size as needed
    ungroup()
  
  #Combine the sampled majority with all minority classes
  combined_data <- bind_rows(sampled_majority, minority_data)
  return(combined_data)
}

#to have diversity among Models, avoid overfitting,each under-sampled dataset provides a different sample of the majority class
n_ensembles <- 15  
under_sampled_datasets <- replicate(n_ensembles, create_under_sampled_dataset(), simplify = FALSE)

#Train multiple Random Forest models
train_random_forest<-function(data) {
  randomForest(Score ~ ., data = data, ntree = 700, mtry=16, importance = TRUE)
}
models <- lapply(under_sampled_datasets, train_random_forest)

#Predict on the test set
predict_after_imbalance_work<-function(model) {
  predict(model, newdata = test_data)  #Get numeric predictions
}
predictions_list <- lapply(models, predict_after_imbalance_work)

#Combine predictions by averaging (for regression, we have regression trees, the value we are trying to predict is numerical)
ensemble_predictions <- rowMeans(do.call(cbind, predictions_list))

#Calculate performance metrics

actual_values <- test_data$Score  #The actual target values in the test set

#Mean Squared Error (MSE)
mse <- mean((ensemble_predictions - actual_values)^2)

#R-squared
r_squared_after_imbalance_work<-1 - (sum((actual_values-ensemble_predictions)^2)/sum((actual_values-mean(actual_values))^2))


#Print performance metrics

print(paste("MSE:", mse))
print(paste("R-squared:", r_squared_after_imbalance_work))








