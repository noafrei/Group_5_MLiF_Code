####################################################################################################################################################################################################

# Machine Learning in Finance: Group 5 Project - Predicting bond ratings for S&P-rated companies using financial ratios
#
# Import data: MLiF_Dataset.csv
# Task: train Linear Regression Algo to predict rating of S%P Rated companies - We did the linear transformation so we are predicting a numeric value, the score
# Joshua Libon, Noa Diego Frei, Lev Akhmerov, Julius Everwand, Leo Koch

####################################################################################################################################################################################################

#Import Libraries needed
library(ggplot2)
library(readr)
library(dplyr)
library(lattice)
library(caret)
library(reshape2)
library(here)


#Begin of Code

#################################################CLEANING OF DATASET (only done once (in RF code), the used also for LR and NN, copy paste in other scripts)########################################
#import the dataset to use
current_context <- rstudioapi::getActiveDocumentContext()
file_path <- current_context$path
parent_directory <- dirname(file_path)
data_folder_path <- file.path(dirname(parent_directory), "Dataset")
csv_path <- file.path(data_folder_path, "MLiF_Dataset.csv")
financial_data <- read_csv(csv_path)
#if that does not work, write: financial_data <- read_csv("...your path/MLiF_Dataset.csv")

#Have a first look at the data
head(financial_data)
column_names <- colnames(financial_data)
column_names

#save original dataset to be used again later if needed
financial_data_2<-financial_data


#Clean the data

#Check for NAs
total_nas <- sum(is.na(financial_data))
if (total_nas!=0){
  print("Pleasem check your data and clean it")
}else{
  print(paste("The total number of NAs is:", total_nas)) # should be 0
}

#clean the dataset columns name-had some problems with the random forest
financial_data <- financial_data %>%
  rename_with(~ gsub(" ", "_", .x)) %>%  # Replace spaces with underscores
  rename_with(~ gsub("/", "_", .x)) %>%  # Replace slashes with underscores
  rename_with(~ gsub("-", "_", .x))       # Replace - with underscores

nrow(financial_data)
ncol(financial_data)

#remove some columns-cleaninig
financial_data <- financial_data[ , !(names(financial_data) %in% c("Global_Company_Key", "Date", "Rating", "Ticker_Symbol", "Quick_Ratio_(Acid_Test)", "Historical_CRSP_PERMNO_Link_to_COMPUSTAT_Record", "Total_Debt_Total_Assets...42"))]
#financial_data <- financial_data[ , !(names(financial_data) %in% c("Global_Company_Key", "Date", "Score", "Ticker_Symbol", "Quick_Ratio_(Acid_Test)", "Historical_CRSP_PERMNO_Link_to_COMPUSTAT_Record", "Total_Debt_Total_Assets...42"))]

column_28_name <- names(financial_data)[28]
print(column_28_name)
colnames(financial_data)[colnames(financial_data) == column_28_name] <- "Total_Debt_Total_Assets"

#Check if it worked
column_names <- colnames(financial_data)
column_names

#Check if each column is a double
double_check <- sapply(financial_data, is.double)
double_check


#For test and train, later useful
target_column <- "Score"
#select only features (all columns except what we want to predict)
features <- financial_data[, setdiff(names(financial_data), target_column)]
target <- financial_data[[target_column]]#what we want to predict
#index of target column
target_column_index <- which(names(financial_data) == target_column)
print(target_column_index)

#more cleaning 
class(financial_data[, target_column_index])
outcome <- financial_data[[target_column_index]]
outcome <- as.numeric(outcome)
class(outcome)
outcome <- financial_data[[target_column_index]]


#convert to vectors to be sure - had some problems with random forest, should already be a vector but just to be sure
financial_data <- financial_data %>%
  mutate_all(as.vector)
#Double check
sapply(financial_data, class)


#Save final cleaned dataset
cleaned_financial_dataset<-financial_data
column_names <- colnames(cleaned_financial_dataset)
column_names
nrow(cleaned_financial_dataset)
ncol(cleaned_financial_dataset)
cleaned_financial_dataset<-as.data.frame(cleaned_financial_dataset)


################################################# END OF CLEANING OF DATASET #######################################################################################################################

################################################ START OF Linear Regression CODE ###################################################################################################################

#Load Libraries
#install.packages("MASS")
library(MASS)

#Simple Linear Regression
#Trained model with the 7 most relevant columns from the Random Forest
lm.fit <- lm(Score ~ Dividend_Payout_Ratio + Interest_Coverage_Ratio + After_tax_Interest_Coverage +
               Long_term_Debt_Total_Liabilities + Enterprise_Value_Multiple + Interest_Average_Total_Debt +
               Interest_Average_Long_term_Debt, data = cleaned_financial_dataset) 
lm.fit #coefficients

#Summary of the model
summary(lm.fit) # Adjusted R-squared: 0.4386

#Set seed for reproducibility of train/test split
set.seed(123)

#Split the data into 70% training and 30% testing to get a feel for how big the error will be
train_indices <- sample(nrow(cleaned_financial_dataset), size = 0.7 * nrow(cleaned_financial_dataset))
train_data <- cleaned_financial_dataset[train_indices, ]
test_data <- cleaned_financial_dataset[-train_indices, ]

#Train the model on the training set
lm.fit <- lm(Score ~ Dividend_Payout_Ratio + Interest_Coverage_Ratio + After_tax_Interest_Coverage +
               Long_term_Debt_Total_Liabilities + Enterprise_Value_Multiple + Interest_Average_Total_Debt +
               Interest_Average_Long_term_Debt, data = train_data)

#Predict on the test set
test_predictions <- predict(lm.fit, newdata = test_data)

#Calculate Mean Squared Error (MSE)
#Test MSE: 5.337573
mean_squared_error <- mean((test_predictions - test_data$Score)^2)
print(mean_squared_error)

#Load library for linear model with Cross Validation (CV)
library(boot)

#Train linear model for 10-fold CV to be able to compare the different models and to reduce the variance of the Test MSE
lm_model <- glm(Score ~ Dividend_Payout_Ratio + Interest_Coverage_Ratio + After_tax_Interest_Coverage +
                  Long_term_Debt_Total_Liabilities + Enterprise_Value_Multiple + Interest_Average_Total_Debt +
                  Interest_Average_Long_term_Debt, data = cleaned_financial_dataset)

#Set seed for reproducibility in cross-validation
set.seed(123)

#Perform 10-fold CV
cv_error <- cv.glm(cleaned_financial_dataset, lm_model, K = 10)

#10-fold CV Test MSE: 5.036737
test_mse_cv <- cv_error$delta[1]
print(test_mse_cv)